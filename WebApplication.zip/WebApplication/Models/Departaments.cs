﻿namespace WebApplication.Models
{
    public class Departaments
    {
        public int Id { get; set; }
        public decimal Financing { get; set; }
        public string Name { get; set; }
    }
}